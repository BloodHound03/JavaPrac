package day16;

public interface I1 {
	int x=100;
	void m1();
}
