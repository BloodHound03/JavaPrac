package day7;
import java.util.Scanner;

public class TakingInputFromKeyboard {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		//Integer
		System.out.println("Enter a number: ");
		int a=sc.nextInt();
		System.out.println("Vaule of a is: "+a);
		
		//Decimal
		System.out.println("Enter a decimal number: ");
		double b=sc.nextDouble();
		System.out.println("Vaule of a is: "+b);
		
		//String
		System.out.println("Enter your name: ");
		String name=sc.next();
		System.out.println("Your name is: "+name );
		
		//

	}

}
