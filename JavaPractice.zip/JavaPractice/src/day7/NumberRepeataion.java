package day7;

public class NumberRepeataion {

	public static void main(String[] args) {
		int a[]= {10,20,10,30,10,40,10,50};
		int num=10;
		int count=0;
		
		for(int x:a) {
			if(x==num) {
				count++;
			}
		}
		System.out.println("Number of times found: "+count);
	}

}
