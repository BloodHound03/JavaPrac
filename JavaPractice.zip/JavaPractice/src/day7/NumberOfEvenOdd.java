package day7;

public class NumberOfEvenOdd {

	public static void main(String[] args) {
		int a[]= {2,3,8,10,15,20,25};
		int odd=0;
		int even=0;
		
		for(int x:a) {
			if(x%2==0) {
				even++;
			}else {
				odd++;
			}
		}
		System.out.println("Number of odd found: "+odd);
		System.out.println("Number of even found: "+even);
	}

}
