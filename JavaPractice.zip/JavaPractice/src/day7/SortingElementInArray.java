package day7;

import java.util.Arrays;

public class SortingElementInArray {

	public static void main(String[] args) {
//		Sorting Numbers
		/*
		 * int a[]= {100,300,200,700,500}; 
		 * System.out.println("Before sorting: "+ Arrays.toString(a)); //[100, 300, 200, 700, 500] 
		 * Arrays.sort(a);
		 * System.out.println("After sorting: "+ Arrays.toString(a)); //[100, 200, 300,
		 * 500, 700]
		 */
		String a[]= {"A","C","E","B","D"};
		System.out.println("Before sorting: "+ Arrays.toString(a));
		Arrays.sort(a);
		System.out.println("After sorting: "+ Arrays.toString(a));
	}
}


