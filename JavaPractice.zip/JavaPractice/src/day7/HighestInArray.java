package day7;

public class HighestInArray {

	public static void main(String[] args) {
		int a[]= {10,20,30,50,40,};
		int num = a[0];
		for(int i=1;i<a.length;i++) {
			if(a[i]>num) {
				num=a[i];
			}
		}
		System.out.println("Highest Number: "+num);
	}

}
