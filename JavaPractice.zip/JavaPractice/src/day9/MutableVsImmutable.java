package day9;

import java.util.Arrays;

public class MutableVsImmutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,30,50,40};
		int b[]=a;
		System.out.println(Arrays.toString(a)); //[10, 20, 30, 50, 40]
		Arrays.sort(a);  //mutable - we can change
		System.out.println(Arrays.toString(a)); //[10, 20, 30, 40, 50]
		System.out.println(Arrays.toString(b)); //[10, 20, 30, 40, 50]
		
		
	}

}
