package day3;

public class IncrementOperator {

	public static void main(String[] args) {
		/*
		 * int a=10; 
		 * // a=a+1; 
		 * a++; 
		 * System.out.println(a);
		 */
		
//		post increment
		/*
		 * int a=10; int res=a++; //before incrementing its assigning the value of a to
		 * res System.out.println(res); //10
		 */	
		
//		pre increment
		/*
		 * int a=10; 
		 * int res=++a; //increment is happening then assigning the value to res 
		 * System.out.println(res); //11
		 */	
		int r=11;
		int o= r++ + ++r;
		System.out.println("Result after increment: "+ o);
		System.out.println("-----------------------------");
			
	} 
}
