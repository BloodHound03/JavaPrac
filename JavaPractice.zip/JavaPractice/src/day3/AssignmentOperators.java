package day3;

public class AssignmentOperators {

	public static void main(String[] args) {
		// Assignment Operators
		
//		Ex 1
		/*
		 * int a=10; 
		 * // a=a+5; 
		 * a+=5; 
		 * System.out.println(a);
		 */
		
//		Ex 2
		/*
		 * int a=10; 
		 * a-=5; //a=a-5 
		 * System.out.println(a);
		 */
		
//		Ex 3
		/*
		 * int a=10; 
		 * a*=2; //a=a*2; 
		 * System.out.println(a);
		 */
		
//		Ex 4
		/*
		 * int a=10; 
		 * a/=2; //a=a/2; 
		 * System.out.println(a);
		 */
		
//		Ex 5
		int d1=10;
		int d2=5;
		System.out.println("d1+=5: "+(d1+=5));  //15
		System.out.println("d1-=5: "+(d1-=5));  //10
		System.out.println("d1*=5: "+(d1*=5));  //50
		System.out.println("d2/=5: "+(d2/=5));  //1
		System.out.println("d2%=5: "+(d2%=5));  //1
		
	}

}
