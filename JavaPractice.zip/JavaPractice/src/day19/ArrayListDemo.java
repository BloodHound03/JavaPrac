package day19;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Declaration
		ArrayList mylist=new ArrayList();
//		List myList=new ArrayList();
//		ArrayList<Integer> myList=new ArrayList<Integer>();
		 
//		Adding data into arrayList
		mylist.add(100);
		mylist.add(10.5);
		mylist.add("Welcome");
		mylist.add('A');
		mylist.add(true);
		mylist.add(100);
		mylist.add(null);
		mylist.add(null);
		
//		size of arrayList
		System.out.println("Size of array list: "+mylist.size());	//Size of array list: 8
//		printing arrayList
		System.out.println("Printing array list: "+mylist);	//Printing array list: [100, 10.5, Welcome, A, true, 100, null, null]

//		Remove duplicate numbers
		mylist.remove(5);	//5 is index of element
		System.out.println("After removig: "+mylist);	//After removig: [100, 10.5, Welcome, A, true, null, null]

//		Insert element in the array
		mylist.add(2,"java");
		System.out.println("After inserting in the list: "+mylist);	//After inserting in the list: [100, 10.5, java, Welcome, A, true, null, null]

//		modify element in the arrayList
		mylist.set(2,"python");
		System.out.println("After replacing in the list: "+mylist);	//After inserting in the list: [100, 10.5, java, Welcome, A, true, null, null]
		
//		Access element in the list
		System.out.println(mylist.get(3));	//here 3 is index	//welcome
		
//		Reading all the elements
//		using normal for loop
		for(int i=0;i<mylist.size();i++) {
			System.out.println(mylist.get(i));
		}
		
//		using enhanced for loop
		for(Object x:mylist) {
			System.out.println(x);
		}
		
//		using iterator
		Iterator it=mylist.iterator();
		
		System.out.println(it.next()); //100
		
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
//		checking arrayList is empty or not
		System.out.println("Is arrayList empty "+mylist.isEmpty());
		
		//remove all elements from arrayList
		ArrayList mylist2=new ArrayList();
		mylist2.add(100);
		mylist2.add("Welcome");
		
		mylist.removeAll(mylist2);
		System.out.println("After remove: "+mylist);	//After remove: [10.5, python, A, true, null, null]
		
//		remove all the elements
		mylist.clear();
		System.out.println("Is arrayList empty "+mylist.isEmpty());		//Is arrayList empty true


	}

}
