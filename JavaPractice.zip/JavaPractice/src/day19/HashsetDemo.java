package day19;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


public class HashsetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		
//		Declaration
		HashSet myset = new HashSet();
//		Set myset=new HashSet();
//		HashSet<String> myset = new HashSet<String>();
		
//		adding elements in to hashset
		myset.add(100);
		myset.add(10.5);
		myset.add("Welcome");
		myset.add(true);
		myset.add('A');
		myset.add(100);
		myset.add(null);
		myset.add(null);
		
//		printing hashset
		System.out.println(myset);	//[null, A, 100, 10.5, Welcome, true]
		
//		removing element
		myset.remove(10.5);
		System.out.println("After removing "+myset);	//After removing [null, A, 100, Welcome, true]
		
		//Inserting element - not possible
		
		//Access specific element - not possible
		
//		Convert HashSet to ArrayList
		ArrayList al = new ArrayList(myset);
		System.out.println(al);		//[null, A, 100, Welcome, true]
		System.out.println(al.get(2));	//100
		
//		Read all element using looping statement
		for(Object x:myset) {
			System.out.println(x);
		}
		
//		using iterator
		Iterator <Object> it=myset.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}

//		clearing all the element in hashset
		myset.clear();
		System.out.println("After removing "+myset.isEmpty());
	}

}
