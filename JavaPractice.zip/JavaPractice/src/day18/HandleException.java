package day18;

import java.util.Scanner;

public class HandleException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program is started...");
		Scanner sc=new Scanner(System.in);
		
//		Example1
		/*
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		try {
			System.out.println(100/num);	//ArithmeticException
		}
		catch(ArithmeticException e) {
			System.out.println("Invalid data Provided");
			System.out.println(e.getMessage());
		}
		
		*/
		
//		Example2
		int a[]= new int[5];
		System.out.println("Enter the position(0-4): ");
		int pos=sc.nextInt();
		
		System.out.println("Enter the value: ");
		int val=sc.nextInt();
		try {
			a[pos]=val;		//ArrayIndexOutOfBoundsException
			System.out.println(a[pos]);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Invalid position provided");
			System.out.println(e.getMessage());
		}
		System.out.println("Program is ended...");
		
	}

}
