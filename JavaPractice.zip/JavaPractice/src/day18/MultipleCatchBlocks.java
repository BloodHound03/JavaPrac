package day18;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.*;
public class MultipleCatchBlocks {
	/*
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Program is started...");
		Scanner sc=new Scanner(System.in);
		
//		Example1
		
		System.out.println("Enter a number: ");
		int num=sc.nextInt();
		try {
			System.out.println(100/num);	//ArithmeticException
		}
		catch(Exception e) {
			System.out.println("Invalid data Provided");
			System.out.println(e.getMessage());
		}
		System.out.println("Program is ended...");

	}*/
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		/*
		 * System.out.println("Program is started...");
		 * System.out.println("Program in progress...");
		 */
		
		FileInputStream file=new FileInputStream("C:\\file.file");
		System.out.println(file.read());
		
		System.out.println("Program is ended...");
		
		} 
}
