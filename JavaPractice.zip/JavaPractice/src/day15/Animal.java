package day15;

public class Animal {
	String color="WHITE";
	void displayColor() {
		System.out.println(color);
	}
	
	void eat() {
		System.out.println("eating.....");
	}
	
	Animal(){
		System.out.println("This is animal.....");
	}
	
	Animal(String name){
		System.out.println(name);
	}
	
}

class Dog extends Animal{
	String color="BLACK ";
	void displayColor() {
		System.out.println(super.color);
	}
	
	void eat() {
		System.out.println("eating meat.....");
		super.eat();
	}
	
	Dog(){
		super(); //invoke parent class constructor
		//System.out.println("This is dog.....");
	}
	
	Dog(String name){
		super(name);
	}
}
