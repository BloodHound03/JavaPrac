package day15;

public class TestSuper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Dog d= new Dog();
		//d.displayColor();
		//d.eat();
		Dog d= new Dog("Elephant");

	}

}
