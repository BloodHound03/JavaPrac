package day17;

public class DataConvertions {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scenario 1
		/*
		String a1="10";
		String s2="20";
		
		int sum=Integer.parseInt(a1)+Integer.parseInt(s2);
		System.out.println(sum);
		
		String s1="10.5";
		String s12="11.5";
		
		double num=Double.parseDouble(s12)+Double.parseDouble(s1);
		System.out.println(num);

		String s="true";
		boolean boolvalue=Boolean.parseBoolean(s);
		System.out.println(boolvalue);
		
		String a="A";
		
	*/
		
//		Scenario 2
		/*
		int x=100;
		double x1 = 10.5;
		boolean x2=true;
		char x3='A';
		String v=String.valueOf(x);
		String v2=String.valueOf(x1);
		String v3=String.valueOf(x2);
		String v4=String.valueOf(x3);
		
		System.out.print(v);
		*/
		
//		int to double we can convert but not the opposite
		
		double d=10.4;
		int x=(int)d;
		System.out.println(x);
	}

}
