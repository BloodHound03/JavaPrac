package day5;

public class DigitCount {
	public static void main(String[] args) {
		int i=423424;
		int leng=0;
		while(i!=0) {
			i /= 10;
			leng++;
		}
		System.out.println(leng);
	}
}
