package day5;

public class JumpingStatements {

	public static void main(String[] args) {
		for(int i=1;i<=10;i++) {
			if(i==5) {
				break;
			}
			System.out.println(i);
		}
		System.out.println("---");
		for(int j=1;j<=10;j++) {
			if(j==5) {
				continue;
			}
			System.out.println(j);
		}
		System.out.println("---");
		for(int x=1;x<=10;x++) {
			if(x==1 || x==5 || x==7) {
				continue;
			}
			System.out.println(x);
		}

	}

}
