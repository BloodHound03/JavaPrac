package day5;

public class WhileLoop {

	public static void main(String[] args) {
		/*int i=1;
		while(i<=10) {
			System.out.println(i);
			i++;
		*/
		/*int i=1;
		while(i<=10) {
			System.out.println(i+"hello");
			i++;
			*/
		int i=10;
		while(i>=1) {
			
				System.out.println(i);
			
			i--;
	}
		

	}

}
