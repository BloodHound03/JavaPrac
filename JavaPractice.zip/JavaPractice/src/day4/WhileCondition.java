package day4;

public class WhileCondition {

	public static void main(String[] args) {
		/*
		 * int i=1, sum=0; 
		 * while(i<=10) { 
		 * 	System.out.println("Iteration number: "+ i);
		 * 	sum+=i; i++; 
		 * } 
		 * System.out.println("Sum of numbers from 1 to 10: "+sum );
		 */
	
		int limit= 1000;
		do {
			System.out.println("Print my transaction");
		}while(limit<=500);
	}

}
