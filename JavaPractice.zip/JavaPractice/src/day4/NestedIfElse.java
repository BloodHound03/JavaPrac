package day4;

public class NestedIfElse {

	public static void main(String[] args) {
		if(1==1) {
			if(2==1) {
				System.out.println("abc");
			}
			else {
				System.out.println(2);
			}
		}
		else{
			if(3==3) {
				System.out.println("xyz");
			}
		}

	}

}
