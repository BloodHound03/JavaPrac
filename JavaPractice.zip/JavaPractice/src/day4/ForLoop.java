package day4;

public class ForLoop {

	public static void main(String[] args) {
		/*
		 * for(int i1=1;i1<=10;i1++) { 
		 * 		if(i1==5) { 
		 * 			continue; 
		 * 		}
		 * 		System.out.println("i value is: "+i1); 
		 * }
		 */		
		for(int a=0;a<=10;a++) {
			for(int b=0;b<=10;b++) {
				System.out.print(a+""+b+" ");
				if(b==9) {
					break;
				}
			}
			System.out.println("");
		}
	}

}
