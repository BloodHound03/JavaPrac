package day4;

public class NumberPosiNegaZero {

	public static void main(String[] args) {
		int num=-10;
		if(num>0) {
			System.out.println("Number is positive");
		}
		else if(num<0){
			System.out.println("Number is negative");
		}
		else{
			System.out.println("Number is zero");
		}
		

	}

}
