package day4;

public class IfELseCondition {

	public static void main(String[] args) {
		int personAge=15;
		if (personAge>=18) {
			System.out.println("Eligible for vote");
		}
		else {
			System.out.println("Not eligible for vote");
		}

	}

}
