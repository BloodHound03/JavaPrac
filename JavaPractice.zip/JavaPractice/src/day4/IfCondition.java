package day4;

public class IfCondition {

	public static void main(String[] args) {
		int personAge=20;
		if (personAge>=18) {
			System.out.println("Eligible for vote");
		}
		
	}

}
