package day12;

//passing copy of the variable
public class CallByValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test test=new Test();
		int num=100;
		System.out.println("Before method: "+num);	//100
		
		test.m1(num);	//110
		
		System.out.println("After method: "+num);  //100

	}

}
