package day12;

public class Test {

	int num;
	void m1(int num){
		num=num+10;
		System.out.println("Value in the method: "+num);
	}
	
	void m2(Test t) {
		t.num+=10;
		System.out.println("Value in the method: "+t.num);
		
	}

}
