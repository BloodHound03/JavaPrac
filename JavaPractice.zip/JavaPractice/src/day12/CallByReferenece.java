package day12;

public class CallByReferenece {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test test=new Test();
		test.num=100;
		System.out.println("Brefore method: "+test.num);
		test.m2(test);
		System.out.println("After method: "+test.num);
		

	}

}
