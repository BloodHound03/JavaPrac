package day12;

public class PassingParamsToMainMethod {

	public static void main(String[] a) {
		// TODO Auto-generated method stub
		for (String s:a) {
			System.out.println(s);
		}

	}

}
