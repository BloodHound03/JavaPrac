package day13;

public class StaticMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(StaticDemo.a);
		StaticDemo.m1();
		
//		System.out.println(b); //we cannot access becoz b is non-static
//		m2(); //cannot access becoz M2 IS NON static
		
		StaticDemo sd=new StaticDemo();
		System.out.println(sd.b);
		sd.m2();
		
		sd.m();

	}

}
