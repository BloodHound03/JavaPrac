package day13;

public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account acc=new Account();
		
		acc.setAccno(10101);
		acc.setName("John");
		acc.setAmount(12321.232);
		
		System.out.println(acc.getAccno());
		System.out.println(acc.getName());
		System.out.println(acc.getAmount());

		
		
	}

}
