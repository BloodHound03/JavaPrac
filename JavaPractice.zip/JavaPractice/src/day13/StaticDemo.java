package day13;

public class StaticDemo {
	
	static int a =10;
	int b=20;
	
	static void m1() { //static method
		System.out.println("this is m1 static method");
	}
	
	static void m2() { //non-static
		System.out.println("this is m2 non-static method");
	}
	
	void m() {
		System.out.println(a);
		System.out.println(b);
		m1();
		m2();
	}

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(a);
		m1();
		
//		System.out.println(b); //we cannot access becoz b is non-static
//		m2(); //cannot access becoz M2 IS NON static
		
		StaticDemo sd=new StaticDemo();
		System.out.println(sd.b);
		sd.m2();
		
		sd.m();
	}*/

}
