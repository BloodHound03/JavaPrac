package day13;

public class ThisKeyword {
	
	int x,y;  //Class variables/Instance variable
	
	void setData(int x, int y) {  //a,b are the local variable
		this.x=x;
		this.y=y;
	}
	
	void display() {
		System.out.println(x+" "+y);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThisKeyword th=new ThisKeyword();
		th.setData(10, 20);
		th.display();

	}

}
