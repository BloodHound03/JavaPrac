package day8;

import java.util.Arrays;

public class StringMethods {

	public static void main(String[] args) {
		String s="Welcome";
		System.out.println(s);
		//length()
		int l=s.length();
		System.out.println(l);
		System.out.println(s.length());
		
		//concat() - join string
		String s1 ="Welcome";
		String s2 =" to java";
		String s3 =" programming";
		
		System.out.println(s1+s2);
		System.out.println(s1.concat(s2));
		
		System.out.println(s1+s2+s3);
		System.out.println(s1.concat(s2).concat(s3));
		
		System.out.println("Welcome"+" Home");
		System.out.println("welcome".concat(" to home"));
		
		//trim() removes spaces right and left side 
		s ="   Welcome   ";
		System.out.println("Before trim:"+s.length()); //13
		s1=s.trim();
		System.out.println("After trim:"+s1.length()); //7
		
		//charAt() returns a character based on index
		//index starts from zero 0
		
		s="Welcome";
		
		System.out.println(s.charAt(3));
		System.out.println(s.charAt(5));
		
		//contains() returns true/false
		//check string is part of the main string
		
		System.out.println(s.contains("Wel")); //true
		System.out.println(s.contains("Come")); //false
		System.out.println(s.contains("come")); //true
		
		System.out.println(s.contains("Welome")); //false
		
		//equals(), equalsIgnorease()- compare 2 strings
		//returns true/false
		s1="Welcome";
		s2="Welcome";
		
		System.out.println(s1.equals(s2));  //true
		System.out.println(s1.equals("welcome")); //false
		System.out.println(s1.equalsIgnoreCase("welcome")); //true
		
		//replace() replace single character/sequence of character in a string
		
		s="Welcome to selenium java python c#";
		System.out.println(s.replace('e', 'X')); //WXlcomX to sXlXnium java python c#
		System.out.println(s.replace("c#", "automation")); //Welcome to selenium java python automation
		
		//substring() extract substring from main string
		s="Welcome";
		System.out.println(s.substring(2,5));
		System.out.println(s.substring(1,3));
		
		//toUpperCase() toLowerCase() converting case
		System.out.println(s.toUpperCase()); //upper case
		System.out.println(s.toLowerCase()); //lower case
		
		//split() split/ divide the string in to multiple parts based on delimiter.
		s="abc@xyz";
		String a[]=s.split("@");
		System.out.println(a[0]); //abc
		System.out.println(a[1]); //xyz
			
		// replace()
		String amount="$15,20,55";
		System.out.println(amount.replace("$", "").replace(",", "")); //152055
		
		s="abc,123@xyz";
		String a1[]=s.split(",");  //abc, 123@xyz
		System.out.println(Arrays.toString(a1));  //abc
		System.out.println(a1[0]);  //abc
		System.out.println(a1[1]);  //123@xyz
		
		String a2[]=a1[1].split("@");
		System.out.println(a2[0]);  //xyz
		System.out.println(a2[1]);  //123
		
		String firstString=s.split(",")[0];  //abc
		String secondString=s.split(",")[1].split("@")[0]; //123
		String thirdString=s.split(",")[1].split("@")[1];  //xyz
		
		System.out.println(firstString);
		System.out.println(secondString);
		System.out.println(thirdString);
		
		s="abc 123 xyz";
		String arr[]=s.split(" ");
		System.out.println(Arrays.toString(arr)); //[abc, 123, xyz]
		
		// * % ^ & ( )  you cannot use as a delimiters
		
	}

}
