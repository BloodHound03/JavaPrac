package day6;

import java.util.Arrays;

public class SingleDimesionalArray {

	public static void main(String[] args) {
		//Declaring array
		/*Approach 1	declaration + adding values
		 * int a[]= new int[5]; 
		 * a[0]=10; 
		 * a[1]=20; 
		 * a[2]=30; 
		 * a[3]=40; 
		 * a[4]=50;
		 */
//		Approach 2		declaration + adding values into array
		int a[]= {10,20,30,40,50};
		
//		Approach 3		Find size of an array
		System.out.println(a.length); //length of an array
		
//		Approach 4		read single value
		System.out.println(a[2]); //30
		System.out.println(a[0]); //10
		
//		Approach 5		read multiple values
		System.out.println(Arrays.toString(a));  //[10, 20, 30, 40, 50]

//		normal for loop
		/*
		 * for(int i=0;i<=a.length-1;i++) { 
		 * 		System.out.println(a[i]); 
		 * }
		 */
		
//		enhanced for loop/ for each loop
		for(int x:a) {
			System.out.println(x);
		}
		
		
		
				
	}

}
