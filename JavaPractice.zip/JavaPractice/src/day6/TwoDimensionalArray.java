package day6;

/**
 * Declare an array 
 * Add values into array 
 * Find size of an array 
 * Read single value from an array 
 * Read multiple values from an array
 */


public class TwoDimensionalArray {

	public static void main(String[] args) {
		// Declaration
		//Approach 1
		/*
		 * int a[][]=new int[3][2]; 
		 * a[0][0]=100; 
		 * a[0][1]=200;
		 * 
		 * a[1][0]=300; 
		 * a[1][1]=400;
		 * 
		 * a[2][0]=500; 
		 * a[2][1]=600;
		 */
		
		//Approach 2
		int a[][]= { {100,200}, {300,400}, {500,600}};
		
		//Approach 3
		System.out.println(a.length);  //returns number of rows
		System.out.println(a[0].length);  //returns number of column in specific row
	
		//Approach 4
		System.out.println(a[1][1]);  //400
		
		//Approach 5
		/*
		 * for(int i=0;i<=a.length-1;i++) { 
		 * for(int j=0;j<=a[i].length-1;j++) {
		 * System.out.print(a[i][j]+"  "); 
		 * } System.out.println(); 
		 * }
		 */
		for(int arr[]:a) {
			for(int x:arr) {
				System.out.print(x+"  ");
			}
			System.out.println();
		}
	}

}
