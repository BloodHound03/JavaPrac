package day2;

public class Variables_DataType{

	public static void main(String[] args) {
//		Example 1
		/*
		 * int a; //declaration 
		 * a = 100; //assignment 
		 * System.out.println(a); //100
		 * a=200; 
		 * System.out.println(a); //200
		 */
		
//		Example 2
		/*
		 * int a=100; //declaration+assignment 
		 * System.out.println(a); 
		 * a=200;
		 * System.out.println(a);
		 */
		
//		Example 3 - all the variables belongs to same data type
		/*
		 * int a=100; 
		 * int b=200; 
		 * int c=300;
		 */
		
//		Example 4 - all the variables belongs to same data type
		/*
		 * int a,b,c; //declared variables 
		 * a=100; 
		 * b=200; 
		 * c=300;
		 */
		
//		Example 5 - in single statement we defines multiple data type
		/*
		 * int a=100,b=200,c=300; 
		 * System.out.println("The value of a is: "+a);
		 * System.out.println("The value of b is: "+b);
		 * System.out.println("The value of c is: "+c);
		 * 
		 * System.out.println(a+" "+b+" "+c);
		 */
//		Numeric Data Types
		
		int a=100,b=200;
		System.out.println(a);
		System.out.println(b);
		System.out.println(a+b);
		
		byte by=120;
		System.out.println(by);
		
		short sh=250;
		System.out.println(sh);
		
		long l=123456789045342l;  //Literal is needed at the end of the value.
		System.out.println(l);
		
		float pr=150.5f;  //Literal is needed at the end of the value.
		System.out.println(pr);
		
		double item_pr=145.46537;
		System.out.println(item_pr);
		
		char grad='B';
		System.out.println("The grade of the student is: "+ grad);
		
		boolean bool=true;  //allowed only true or false
		System.out.println(bool);
		
		String name="Tatha";
		System.out.println(name);
		
	}

}
