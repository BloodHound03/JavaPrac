package day10;

public class EmployeeMainCLass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Employee emp1=new Employee();
		emp1.eid=101;
		emp1.ename="tanya";
		emp1.job="Programmer";
		emp1.sal=2000;
		emp1.display();

	}

}
