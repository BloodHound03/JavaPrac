package day10;

public class Employee {
	
	int eid;
	String ename;
	String job;
	int sal;
	
	void display() {
		System.out.println(eid);
		System.out.println(ename);
		System.out.println(job);
		System.out.println(sal);
	}
	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp1=new Employee();
		emp1.eid=101;
		emp1.ename="Tathagata";
		emp1.job="ceo";
		emp1.sal=20000000;
		emp1.display();
		
		Employee emp2=new Employee();
		emp2.eid=102;
		emp2.ename="Tanya";
		emp2.job="Assistant Manager";
		emp2.sal=5000000;
		emp2.display();
		
		
	}*/

}
