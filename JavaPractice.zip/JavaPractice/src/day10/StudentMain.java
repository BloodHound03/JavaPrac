package day10;

public class StudentMain {
	public static void main(String[] args) {
		
		//creating object with reference variable
		/*
		Student stu=new Student();
		stu.sid=1010;
		stu.sname="Krishna";
		stu.grad='A';
		
		stu.printStudentData();
		*/
		
		//creating object without reference variable
		/*new Student();
		new Student().sid=102;
		new Student().sname="John";
		new Student().grad='B';
		new Student().printStudentData();
		*/
		
		
	}

}
