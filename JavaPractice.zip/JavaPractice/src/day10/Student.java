package day10;

public class Student {
	
	int sid;
	String sname;
	char grad;

	void printStudentData() {
		// TODO Auto-generated method stub
		System.out.println(sid+" "+sname+" "+grad);

	}

}
