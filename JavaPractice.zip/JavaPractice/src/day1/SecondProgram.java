package day1;

public class SecondProgram {

	public static void main(String[] args) {
		System.out.println("Welcome");
		System.out.println(1+2);
		System.out.println("1+2");
		System.out.println("Welcome"+123);
//		System.out.println(Welcome);
		/*
		 * System.out.println("Welcome"+123); 
		 * System.out.println("Welcome"+123);
		 * System.out.println("Welcome"+123); 
		 * System.out.println("Welcome"+123);
		 * System.out.println("Welcome"+123); 
		 * System.out.println("Welcome"+123);
		 * System.out.println("Welcome"+123);
		 */		
	}

}
