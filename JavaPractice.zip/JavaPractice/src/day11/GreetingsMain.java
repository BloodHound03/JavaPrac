package day11;

public class GreetingsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Greetings gr=new Greetings();
		//gr.m1();
		//String s=gr.m2();
		//System.out.println(s);
		
		System.out.println(gr.m2());
		
		gr.m3("Tatha");
		
		String sr=gr.m4("Yo");
		System.out.println(sr);
		
		System.out.println(gr.m4("Mo"));
		
	}

}
