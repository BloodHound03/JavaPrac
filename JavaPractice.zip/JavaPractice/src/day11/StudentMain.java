package day11;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Student stu=new Student();
		
		
		/*//1) assign the data using object reference
		stu.sid=101;
		stu.sname="Tatha";
		stu.grade='A';
		
		stu.printStuData();
		*/
		
		//2) assing data by using user defined data
		//stu.setStuData(101, "John", 'B');
		
		//3) using constructor
		Student stu=new Student(101, "Tathagata",'B');
		
		stu.printStuData();

	}

}
