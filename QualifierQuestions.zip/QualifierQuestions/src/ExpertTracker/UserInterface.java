package ExpertTracker;

import java.util.Scanner;
import java.util.Set;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		ExpertCatalog catalog=new ExpertCatalog();
		
		System.out.println("Enter the number of experts");
		int num=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the expert details (Name:Topic)");
		for(int i=0; i<num; i++) {
			String details=sc.nextLine();
			catalog.addExpert(details);
		}
		
		System.out.println("Enter the topic");
		String topic= sc.nextLine();
		
		Set<String> experts=catalog.getExpertByTopic(topic);
		
		if(experts.isEmpty()) {
			System.out.println("No experts are found for the topic "+topic);
		} else {
			System.out.println("Experts specializing in "+topic);
			for(String expert:experts) {
				System.err.println(expert);
			}
		}		
	}
}
