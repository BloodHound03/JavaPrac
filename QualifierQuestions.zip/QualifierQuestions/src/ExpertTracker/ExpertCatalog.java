package ExpertTracker;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Set;

public class ExpertCatalog {
	private HashMap<String, String> expertCatalog = new HashMap<>();
	
	
	public HashMap<String, String> getExpertCatalog() {
		return expertCatalog;
	}

	public void setExpertCatalog(HashMap<String, String> expertCatalog) {
		this.expertCatalog = expertCatalog;
	}

	public void addExpert(String expertDetails) {
		String[] parts=expertDetails.split(":");
		if(parts.length==2) {
			String expertName=parts[0];
			String topic=parts[1];
			expertCatalog.put(expertName,topic);
		}
	}
	
	public Set<String> getExpertByTopic(String topic){
		Set<String> result=new HashSet<>();
		for(Entry<String, String> entry:expertCatalog.entrySet()) {
			if(entry.getValue().equalsIgnoreCase(topic)) {
				result.add(entry.getKey());
			}
		}
		return result;
	}
}
	
