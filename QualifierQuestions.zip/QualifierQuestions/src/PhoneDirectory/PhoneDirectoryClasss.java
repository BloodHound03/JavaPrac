package PhoneDirectory;
import java.util.*;

public class PhoneDirectoryClasss {
	
	private Map<String, String>	contactDirectory=new HashMap<>();
	public void addContactRecord(String contactData) {
		String[] parts=contactData.split(":");
		if(parts.length==2) {
			String name=parts[0];
			String phoneNumber=parts[1];
			contactDirectory.put(name, phoneNumber);
		}
	}
	
	public HashSet<String> getPhoneNumbers(String searchKeyboard){
		HashSet<String> phoneNumbers=new HashSet<>();
		for(Map.Entry<String, String> entry:contactDirectory.entrySet()) {
			if(entry.getKey().contains(searchKeyboard)) {
				phoneNumbers.add(entry.getValue());
			}
		}
		return phoneNumbers;
	}
}
