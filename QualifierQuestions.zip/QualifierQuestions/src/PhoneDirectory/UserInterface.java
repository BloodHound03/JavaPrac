package PhoneDirectory;
import java.util.*;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		PhoneDirectoryClasss directory=new PhoneDirectoryClasss();
		
		System.out.println("Enter the number of contacts to add");
		int num=Integer.parseInt(sc.nextLine());
		
		System.out.println("Enter the contact names and number");
		for(int i=0;i<num;i++) {
			String data=sc.nextLine();
			directory.addContactRecord(data);
		}
		
		System.out.println("Enter the search keyword");
		String keyw=sc.nextLine();
		
		HashSet<String> result= directory.getPhoneNumbers(keyw);
		if(result.isEmpty()) {
			System.out.println("No phone number found with keyword "+keyw);
		}else {
			System.out.println("Phone number for the keyword "+keyw+":");
			for(String numb:result) {
				System.out.println(numb);
			}
		}		
	}
}
