package CouponCreator;
import java.util.Scanner;
public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the camera specification");
		String cname=sc.nextLine();
		if(cname.equals("RIKON")) {
			String surname=sc.nextLine();
			if(surname.length()==3 || surname.length()==4) {
				int isoVal=sc.nextInt();
				sc.nextLine();
				if(isoVal==100 || isoVal==200 || isoVal==400 || isoVal==800) {
					String camMode=sc.nextLine();
					if(camMode.equalsIgnoreCase("Auto") || camMode.equalsIgnoreCase("Manual")) {
						String panNo=sc.nextLine();
						if(panNo.length()==10 && panNo.matches("[A-Z]{5}\\w*")) {
							String coup="RIK"+surname.toUpperCase().charAt(0)+isoVal+camMode.toUpperCase().charAt(0)+panNo.substring(0,5);
							System.out.println("Your coupon code is "+coup);
						}else {
							System.out.println(panNo+" is an invalid PAN number");
						}
					}else {
						System.out.println(camMode+" is an invalid camera mode");
					}
				} else {
					System.out.println(isoVal+" is invalid ISO");
				}
			} else {
				System.out.println(surname+" is an invalid customer surname");
			}
		} else {
			System.out.println(cname+" is an invalid company name");
		}

	}

}
