package MovieStreamer;

import java.util.List;
import java.util.ArrayList;


public class MovieManager {
	private List<String> movieList=new ArrayList<>();
	
	public void addMovieDetails(String movieDetails) {
		movieList.add(movieDetails);
	}
	
	public List<String> getMoviesByRating(double minRating){
		List<String> result=new ArrayList<>();
		for(String details:movieList) {
			String[] parts= details.split(":");
			if(parts.length==2) {
				String title=parts[0];
				//double rating=Double.parseDouble(parts[1]);
				if(Double.parseDouble(parts[1])>=minRating) {
					result.add(title);
				}
			}
		}
		return result;
	}	
}
