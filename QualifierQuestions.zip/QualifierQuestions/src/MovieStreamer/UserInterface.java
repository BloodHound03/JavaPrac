package MovieStreamer;

import java.util.List;
import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		MovieManager manager=new MovieManager();
		
		System.out.println("Enter the number of movies to be added");
		//int num=Integer.parseInt(sc.nextLine());
		int num = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the movie details");
		for(int i=0; i<num; i++) {
			String details=sc.nextLine();
			manager.addMovieDetails(details);
		}
		
		System.out.println("Enter the minimum rating");
		double minRating= sc.nextDouble();
		
		List <String> filteredMovies=manager.getMoviesByRating(minRating);
		if(filteredMovies.isEmpty()) {
			System.out.println("No movies are found with minimum rating of "+minRating);
		} else {
			System.out.println("Movies with a rating atleast "+minRating);
			for(String title:filteredMovies) {
				System.out.println(title);
			}
		}

	}

}
