package SaraSumMax;
import java.util.Arrays;
import java.util.Scanner;


public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the array size");
		int arrSize=sc.nextInt();
		if(arrSize<=1 || arrSize%2!=0) {
			System.out.println(arrSize+" is an invalid number");
			return;
		}
		
		int[] num=new int[arrSize];
		System.out.println("Enter the numbers");
		for(int i=0;i<arrSize;i++) {
			num[i]=sc.nextInt();			
		}
		Arrays.sort(num);
		
		int maxSum=Integer.MIN_VALUE;
		for(int i=0;i<arrSize/2;i++) {
			int sum=num[arrSize-1-i]+ num[i];
			if(sum>maxSum) {
				maxSum=sum;
			}
		}
		System.out.println("The maximum number is "+maxSum);
	}

}
