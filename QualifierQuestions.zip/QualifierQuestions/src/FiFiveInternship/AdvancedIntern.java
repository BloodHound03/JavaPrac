package FiFiveInternship;

public class AdvancedIntern extends Intern{
	private int noOfHours;
	private double instructorFee;
	
	public int getNoOfHours() {
		return noOfHours;
	}
	public void setNoOfHours(int noOfHours) {
		this.noOfHours = noOfHours;
	}
	public double getInstructorFee() {
		return instructorFee;
	}
	public void setInstructorFee(double instructorFee) {
		this.instructorFee = instructorFee;
	}
	
	public AdvancedIntern(String name, String emailid, String collegeName, String location, String type, double certificationFee, int noOfHours, double instructorFee) {
		super(name, emailid, collegeName, location, type, certificationFee);
		this.noOfHours = noOfHours;
		this.instructorFee = instructorFee;
	}
	
	public double calculateAdvancedInternFees() {
		double typeFee = switch(type) {
		case "Technical" -> 150;
		case "Research" -> 250;
		case "Business" -> 350;
		default -> -1;
		};
		if(typeFee == -1) return -1;
		return certificationFee+instructorFee+(typeFee*noOfHours);
	}

}
