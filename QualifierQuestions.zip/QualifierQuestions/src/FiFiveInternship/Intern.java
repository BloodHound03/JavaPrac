package FiFiveInternship;

public class Intern {
	
	protected String name;
	protected String emailid;
	protected String collegeName;
	protected String location;
	protected String type;
	protected double certificationFee;
	
	public Intern(String name, String emailid, String collegeName, String location, String type, double certificationFee) {
		this.name = name;
		this.emailid = emailid;
		this.collegeName = collegeName;
		this.location = location;
		this.type = type;
		this.certificationFee = certificationFee;		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getCertificationFee() {
		return certificationFee;
	}
	public void setCertificationFee(double certificationFee) {
		this.certificationFee = certificationFee;
	}

}
