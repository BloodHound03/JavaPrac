package FiFiveInternship;

public class BeginnerIntern extends Intern {
	private int noOfDays;
	private double platformFee;
	
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public double getPlatformFee() {
		return platformFee;
	}
	public void setPlatformFee(double platformFee) {
		this.platformFee = platformFee;
	}
	
	public BeginnerIntern(String name, String emailid, String collegeName, String location, String type, double certificationFee, int noOfDays, double platformFee) {
		super(name, emailid, collegeName, location, type, certificationFee);
		this.noOfDays = noOfDays;
		this.platformFee = platformFee;
	}
	
	public double calculateBeginnerInternFees() {
		double typeFee = switch(type) {
		case "Technical" -> 100;
		case "Research" -> 200;
		case "Business" -> 300;
		default -> -1;
		};
		if(typeFee == -1) return -1;
		return certificationFee+platformFee+(typeFee*noOfDays);
	}

}
