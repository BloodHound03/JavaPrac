package FiFiveInternship;
import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);

        System.out.println("Enter Intern details");
        String input=sc.nextLine();
        String[] parts=input.split(":");
        
        if(parts.length==0) {
        	System.out.println("Invalid input");
        	return;
        }
        
        String internLevel =parts[0];
        if(internLevel.equals("Beginner") && parts.length==9) {
        	String name= parts[1];
        	String email= parts[2];
        	String college= parts[3];
        	String location= parts[4];
        	String type= parts[5];
        	double certFee= Double.parseDouble(parts[6]);
        	int noOfDays=Integer.parseInt(parts[7]);
        	double platformFee = Double.parseDouble(parts[8]);
        	
        	BeginnerIntern bi= new BeginnerIntern(name, email, college, location, type, certFee, noOfDays, platformFee);
        	double fee=bi.calculateBeginnerInternFees();
        	
        	if(fee == -1) {
        		System.out.println("Invalid type of internship "+type);
        	} else {
        		System.out.println("Calculated beginner intern fees for "+type+" internship is "+fee);
        	}
        }
        else if(internLevel.equals("Advanced") && parts.length==9) {
        	String name= parts[1];
        	String email= parts[2];
        	String college= parts[3];
        	String location= parts[4];
        	String type= parts[5];
        	double certFee= Double.parseDouble(parts[6]);
        	int noOfHours=Integer.parseInt(parts[7]);
        	double instructorFee = Double.parseDouble(parts[8]);
        	
        	AdvancedIntern ai= new AdvancedIntern(name, email, college, location, type, certFee, noOfHours, instructorFee);
        	double fee=ai.calculateAdvancedInternFees();
        	
        	if(fee == -1) {
        		System.out.println("Invalid type of internship "+type);
        	} else {
        		System.out.println("Calculated advanced intern fees for "+type+" internship is "+fee);
        	}
        } else {
        	System.out.println("Invalid intern level");	
        }
	}
}
