package PostScheduler;

public class InvalidPostException extends Exception {

	public InvalidPostException(String message)  {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
