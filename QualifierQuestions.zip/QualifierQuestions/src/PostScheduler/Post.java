package PostScheduler;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Post {
	private String postId;
	private String content;
	private String platform;
	private String scheduledTime;
	
	public Post(String postId, String content, String platform, String scheduledTime) {
		this.postId=postId;
		this.content = content;
		this.platform = platform;
		this.scheduledTime = scheduledTime;
		
	}
	public String getPostId() {
		return postId;
	}
	public void setPostId(String postId) {
		this.postId = postId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPlatform() {
		return platform;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public String getScheduledTime() {
		return scheduledTime;
	}
	public void setScheduledTime(String scheduledTime) {
		this.scheduledTime = scheduledTime;
	}
	
	
	/*
	public Post(String postId2, String content2, String platform2, LocalDateTime scheduledTime1) {
		// TODO Auto-generated constructor stub
	}
	
	public static Post verifyPostDetails(String postDetails) throws InvalidPostException  {
		String[] parts=postDetails.split("&");
		if(parts.length != 4) {
			throw new InvalidPostException("Invalid post details length");
		}
		String postId=parts[0];
		String content=parts[1];
		String platform=parts[2];
		String scheduledTime=parts[3];
		
		if(!postId.matches("POST-\\d{5}")) {
			throw new InvalidPostException("Invalid Post details");
		}
		if(content.isEmpty() || content.length()>280) {
			throw new InvalidPostException("Invalid Content details");
		}
		String[] validPlatforms= {"Facebook", "Twitter", "Instagram", "LinkedIn"};
		boolean platformValid=false;
		for(String p:validPlatforms) {
			if(p.equalsIgnoreCase(platform)) {
				platform=p;
				platformValid=true;
				break;
			}
		}
		if(!platformValid) {
			throw new InvalidPostException("Invalid Platform details");
		}
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		LocalDateTime scheduledTime1;
		try {
			scheduledTime1=LocalDateTime.parse(scheduledTime, formatter);
		} catch(DateTimeParseException e) {
			throw new InvalidPostException("Invalid Time details");
		}
		/*if(!scheduledTime.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")) {
			throw new InvalidPostException("Invalid Time details");
		}
		return new Post(postId, content, platform, scheduledTime1);
	}*/
	public Post(){
		
	}


	public static Post verifyPostDetails(String postDetails) throws InvalidPostException{
		String[] details=postDetails.split("&");
		DateTimeFormatter df=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		if(!details[0].matches("POST-\\d{5}") || 
				!(details[1].length()>=1 || details[1].length()<=280) ||
				!(details[2].equalsIgnoreCase("Facebook") || details[2].equalsIgnoreCase("Twitter") || 
				details[2].equalsIgnoreCase("Instagram") || details[2].equalsIgnoreCase("LinkedIn"))) {
			throw new InvalidPostException("Invalid Post details");
		}
		try {
			LocalDateTime.parse(details[3],df);
		} catch(DateTimeParseException e) {
			throw new InvalidPostException("Invalid Post details");
		}
		return new Post(details[0],details[1],details[2],details[3]);
	}
}
