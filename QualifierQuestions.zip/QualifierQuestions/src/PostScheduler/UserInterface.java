package PostScheduler;
import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the post details");
		String input = sc.nextLine(); 
		
		try {
			Post post= Post.verifyPostDetails(input);
			System.out.println("Post Details");
			System.out.println("Post ID: "+ post.getPostId());
			System.out.println("Content: "+ post.getContent());
			System.out.println("Platform: "+ post.getPlatform());
			System.out.println("Scheduled Time: "+ post.getScheduledTime());
		}
		catch(InvalidPostException e) {
			System.out.println(e.getMessage());
		}
	}

}
